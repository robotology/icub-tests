robot-testing
=============

A suite of tests for robots or simulators.

Documentation available at http://robotology.github.io/robot-testing.